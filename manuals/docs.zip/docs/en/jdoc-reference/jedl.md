<!-- Filename: JEDL / Display title: JEDL Licence -->

Below is a license granting you rights to use, modify and distribute
documentation associated with the Joomla! project. It is designed to
foster wide electronic distribution of Joomla! documentation while
ensuring that any material added to the documentation by you or others
can be taken up and made part of the authoritative documentation
distributed by the Joomla! project.

The license that appears below is not the only way to get permission to
use Joomla! documentation. If you want to publish Joomla! documentation
in a manner not permitted by this license (i.e. in a printed book),
please contact the Joomla! project.

Although the license is called the "**Joomla! Electronic Documentation
License**", you are encouraged to use it for works not associated with
Joomla! and for things other than documentation.

The license itself is copyright 2007 Open Source Matters, Inc., and you
have permission to make verbatim copies of it.

## Joomla! Electronic Documentation License v 1.0

### Definitions

To "Propagate" a work means to do anything with it that, without
permission, would make you directly or secondarily liable for
infringement under applicable copyright law, except displaying or
modifying a private copy.

The "Work" is any copyrightable material licensed under the terms of
this license or any material based on such material. The "Author" means
all the people or entities who have the legal right to grant permission
to Propagate the Work or parts of the Work. Each licensee is addressed
as "you".

"Electronic Media" means any device, medium or technology used to store,
record, display, transmit or modify electronic information, including
websites, compact discs, digital video discs, hard disks, magnetic
media, and computer networks. "Electronic Media" does not include, for
example, books printed on paper.

"Grantback License" means a non-exclusive, perpetual, worldwide,
royalty-free license to Propagate the Work in any medium and by any
means.

"Copyleft License" means a license to Propagate the Work under the terms
of this license or any future version of the Joomla Electronic
Documentation License published by Open Source Matters, Incorporated.

The "Source Form" of a work means the preferred form of the Work for
making modifications to it. For text works, this could be plain ASCII
text format.

### Conditional Permissions

If you grant a Grantback License to the Author and a Copyleft License to
anybody who comes into possession of the Work, you may Propagate the
Work via Electronic Media for any purpose, including commercial
purposes.

You must make available at no charge, to anybody to whom you distribute
the Work, a version of the Work in Source Form. Such availability must
be via either (1) the same means and method with which you distribute
the Work or (2) simple download over the internet. You may not condition
providing the Source Form of the Work on anything other than acceptance
of this license.

You must provide a copy of this license, notice that it applies to the
Work, and information needed to acquire the Source Form to anybody to
whom you distribute the Work.

You must preserve the Author's copyright notices in the Work and display
them as prominently as you display your own.

### Reservations of Rights

Nothing in this license grants you or anybody else any right to
Propagate the Work in any medium or through any means other than
Electronic Media.

Nothing in this license grants you or anybody else any right to do
anything that requires permission under trademark law. Specifically,
nothing in this license grants you permission to represent that the Work
is "official" or in any way endorsed or sanctioned by the Authors.
